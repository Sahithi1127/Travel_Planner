# Travel Planner Flutter App

A portfolio-ready Flutter travel planner demonstrating:

- Dart + Flutter SDK
- Provider state management
- REST API integration
- Search and filtering
- Trip creation and itinerary management
- Local persistence with SharedPreferences
- Responsive Material UI/UX
- Loading, error and empty states
- Firebase-ready service separation

## Run

```bash
flutter pub get
flutter run
```

## REST API

The app uses the public REST Countries API:

https://restcountries.com/

No API key is required.

## Firebase

Firebase integration is intentionally isolated so the project can run immediately without Firebase configuration. To enable Firebase later:

```bash
flutter pub add firebase_core firebase_auth cloud_firestore firebase_storage
dart pub global activate flutterfire_cli
flutterfire configure
```

Then initialize Firebase in `main.dart` and replace the local persistence service with Firestore/Auth services.

## Suggested portfolio improvements

- Add Google Maps/Mapbox
- Add weather API
- Add hotel/flight API
- Add Firebase Authentication
- Store trips in Firestore
- Add push notifications
- Add image caching
