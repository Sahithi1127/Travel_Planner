import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/destination.dart';

class ApiService {
  static const String baseUrl = 'https://restcountries.com/v3.1';

  Future<List<Destination>> fetchDestinations() async {
    final uri = Uri.parse(
      '$baseUrl/all?fields=name,capital,region,flags',
    );

    final response = await http.get(uri);

    if (response.statusCode != 200) {
      throw Exception('Unable to load destinations (${response.statusCode})');
    }

    final List<dynamic> data = jsonDecode(response.body);

    return data
        .map((item) => Destination.fromJson(item as Map<String, dynamic>))
        .where((destination) => destination.name.isNotEmpty)
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }
}
