import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/trip.dart';

class StorageService {
  static const _tripsKey = 'saved_trips';

  Future<List<Trip>> loadTrips() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_tripsKey);

    if (raw == null) return [];

    final List<dynamic> data = jsonDecode(raw);
    return data
        .map((item) => Trip.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveTrips(List<Trip> trips) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _tripsKey,
      jsonEncode(trips.map((trip) => trip.toJson()).toList()),
    );
  }
}
