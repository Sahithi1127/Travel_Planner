import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/destination.dart';
import '../providers/travel_provider.dart';
import 'add_trip_screen.dart';

class DestinationDetailsScreen extends StatelessWidget {
  final Destination destination;

  const DestinationDetailsScreen({
    super.key,
    required this.destination,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(destination.name),
              background: destination.flagUrl.isEmpty
                  ? const ColoredBox(color: Colors.blueGrey)
                  : Image.network(
                      destination.flagUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          const ColoredBox(color: Colors.blueGrey),
                    ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    destination.name,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    destination.country,
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 22),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _InfoChip(
                        icon: Icons.location_city,
                        label: destination.capital,
                      ),
                      _InfoChip(
                        icon: Icons.public,
                        label: destination.region,
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'About this destination',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    destination.description,
                    style: TextStyle(
                      height: 1.6,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () {
                        context.read<TravelProvider>().setQuery('');
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AddTripScreenWithDestination(
                              destination: destination.name,
                            ),
                          ),
                        );
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Plan a Trip Here'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
    );
  }
}

class AddTripScreenWithDestination extends StatefulWidget {
  final String destination;

  const AddTripScreenWithDestination({
    super.key,
    required this.destination,
  });

  @override
  State<AddTripScreenWithDestination> createState() =>
      _AddTripScreenWithDestinationState();
}

class _AddTripScreenWithDestinationState
    extends State<AddTripScreenWithDestination> {
  DateTime? start;
  DateTime? end;

  Future<void> pick(bool isStart) async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: DateTime(now.year + 5),
      initialDate: isStart ? (start ?? now) : (end ?? start ?? now),
    );

    if (date == null) return;

    setState(() {
      if (isStart) {
        start = date;
        if (end != null && end!.isBefore(date)) end = date;
      } else {
        end = date;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Plan Trip')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              widget.destination,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              leading: const Icon(Icons.flight_takeoff),
              title: const Text('Start date'),
              subtitle: Text(start == null ? 'Select date' : start!.toString().split(' ').first),
              onTap: () => pick(true),
            ),
            const SizedBox(height: 12),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              leading: const Icon(Icons.flight_land),
              title: const Text('End date'),
              subtitle: Text(end == null ? 'Select date' : end!.toString().split(' ').first),
              onTap: () => pick(false),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: start == null || end == null
                    ? null
                    : () async {
                        await context.read<TravelProvider>().addTrip(
                              destination: widget.destination,
                              startDate: start!,
                              endDate: end!,
                            );
                        if (mounted) Navigator.pop(context);
                      },
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('Save Trip'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
