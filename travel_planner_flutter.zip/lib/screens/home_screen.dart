import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/travel_provider.dart';
import '../widgets/destination_card.dart';
import '../widgets/trip_card.dart';
import 'add_trip_screen.dart';
import 'destination_details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'WanderPlan',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: provider.loadInitialData,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _index == 0
          ? _explore(context)
          : _trips(context),
      floatingActionButton: _index == 1
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddTripScreen()),
              ),
              icon: const Icon(Icons.add),
              label: const Text('Plan Trip'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Explore',
          ),
          NavigationDestination(
            icon: Icon(Icons.luggage_outlined),
            selectedIcon: Icon(Icons.luggage),
            label: 'My Trips',
          ),
        ],
      ),
    );
  }

  Widget _explore(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return RefreshIndicator(
      onRefresh: provider.loadInitialData,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: _header(context)),
          if (provider.loading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator()),
            )
          else if (provider.error != null)
            SliverFillRemaining(child: _error(context, provider.error!))
          else if (provider.destinations.isEmpty)
            const SliverFillRemaining(
              child: Center(child: Text('No destinations found')),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final destination = provider.destinations[index];
                    return DestinationCard(
                      destination: destination,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DestinationDetailsScreen(
                            destination: destination,
                          ),
                        ),
                      ),
                    );
                  },
                  childCount: provider.destinations.length,
                ),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 360,
                  mainAxisExtent: 270,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _header(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    final regions = provider.destinations
        .map((e) => e.region)
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Where will you go next?',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          Text(
            'Discover destinations and build your perfect itinerary.',
            style: TextStyle(color: Colors.grey.shade600),
          ),
          const SizedBox(height: 18),
          TextField(
            onChanged: provider.setQuery,
            decoration: const InputDecoration(
              hintText: 'Search country or capital',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 42,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: provider.region == null,
                  onSelected: (_) => provider.setRegion(null),
                ),
                const SizedBox(width: 8),
                ...regions.take(8).map(
                  (region) => Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(region),
                      selected: provider.region == region,
                      onSelected: (_) => provider.setRegion(
                        provider.region == region ? null : region,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _trips(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    if (provider.trips.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.luggage_outlined,
                  size: 72, color: Colors.blueGrey.shade200),
              const SizedBox(height: 18),
              const Text(
                'No trips yet',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Create your first travel plan and keep everything organized.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 100),
      itemCount: provider.trips.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, index) {
        final trip = provider.trips[index];
        return TripCard(
          trip: trip,
          onDelete: () => provider.deleteTrip(trip.id),
        );
      },
    );
  }

  Widget _error(BuildContext context, String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off, size: 64),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: context.read<TravelProvider>().loadInitialData,
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }
}
