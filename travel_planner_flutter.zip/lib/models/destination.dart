class Destination {
  final String name;
  final String country;
  final String capital;
  final String region;
  final String flagUrl;
  final String description;

  const Destination({
    required this.name,
    required this.country,
    required this.capital,
    required this.region,
    required this.flagUrl,
    required this.description,
  });

  factory Destination.fromJson(Map<String, dynamic> json) {
    final nameMap = (json['name'] as Map?)?.cast<String, dynamic>() ?? {};
    final flags = (json['flags'] as Map?)?.cast<String, dynamic>() ?? {};

    return Destination(
      name: nameMap['common']?.toString() ?? 'Unknown',
      country: nameMap['official']?.toString() ?? 'Unknown',
      capital: ((json['capital'] as List?)?.isNotEmpty ?? false)
          ? json['capital'][0].toString()
          : 'N/A',
      region: json['region']?.toString() ?? 'Unknown',
      flagUrl: flags['png']?.toString() ?? '',
      description: 'Explore culture, food, landmarks and experiences in this destination.',
    );
  }
}
