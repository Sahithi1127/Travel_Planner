class Trip {
  final String id;
  final String destination;
  final DateTime startDate;
  final DateTime endDate;
  final String notes;

  Trip({
    required this.id,
    required this.destination,
    required this.startDate,
    required this.endDate,
    this.notes = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'destination': destination,
        'startDate': startDate.toIso8601String(),
        'endDate': endDate.toIso8601String(),
        'notes': notes,
      };

  factory Trip.fromJson(Map<String, dynamic> json) => Trip(
        id: json['id'],
        destination: json['destination'],
        startDate: DateTime.parse(json['startDate']),
        endDate: DateTime.parse(json['endDate']),
        notes: json['notes'] ?? '',
      );
}
