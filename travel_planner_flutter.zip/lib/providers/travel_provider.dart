import 'package:flutter/foundation.dart';

import '../models/destination.dart';
import '../models/trip.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';

class TravelProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  final StorageService _storage = StorageService();

  List<Destination> _destinations = [];
  List<Trip> _trips = [];
  String _query = '';
  String? _region;
  bool _loading = false;
  String? _error;

  List<Destination> get destinations {
    final result = _destinations.where((destination) {
      final matchesQuery = destination.name.toLowerCase().contains(
            _query.toLowerCase(),
          ) ||
          destination.capital.toLowerCase().contains(_query.toLowerCase());

      final matchesRegion =
          _region == null || destination.region == _region;

      return matchesQuery && matchesRegion;
    }).toList();

    return result.take(80).toList();
  }

  List<Trip> get trips => List.unmodifiable(_trips);
  bool get loading => _loading;
  String? get error => _error;
  String get query => _query;
  String? get region => _region;

  Future<void> loadInitialData() async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final results = await Future.wait([
        _api.fetchDestinations(),
        _storage.loadTrips(),
      ]);

      _destinations = results[0] as List<Destination>;
      _trips = results[1] as List<Trip>;
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  void setQuery(String value) {
    _query = value;
    notifyListeners();
  }

  void setRegion(String? value) {
    _region = value;
    notifyListeners();
  }

  Future<void> addTrip({
    required String destination,
    required DateTime startDate,
    required DateTime endDate,
    String notes = '',
  }) async {
    _trips.add(
      Trip(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        destination: destination,
        startDate: startDate,
        endDate: endDate,
        notes: notes,
      ),
    );

    await _storage.saveTrips(_trips);
    notifyListeners();
  }

  Future<void> deleteTrip(String id) async {
    _trips.removeWhere((trip) => trip.id == id);
    await _storage.saveTrips(_trips);
    notifyListeners();
  }
}
