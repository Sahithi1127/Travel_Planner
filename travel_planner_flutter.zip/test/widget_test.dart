import 'package:flutter_test/flutter_test.dart';
import 'package:travel_planner/main.dart';

void main() {
  testWidgets('Travel Planner app loads', (tester) async {
    await tester.pumpWidget(const TravelPlannerApp());
    expect(find.text('WanderPlan'), findsOneWidget);
  });
}
